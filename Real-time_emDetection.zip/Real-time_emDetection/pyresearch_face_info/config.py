# -------------------------------------- emotion_detection ---------------------------------------

path_model = 'emotion_detection/Modelos/model_dropout.hdf5'
w, h = 48, 48
rgb = False
labels = ['angry', 'disgust', 'fear', 'happy', 'neutral', 'sad', 'surprise']

# -------------------------------------- face_recognition ---------------------------------------
# path images folder
path_images = "path_im"
